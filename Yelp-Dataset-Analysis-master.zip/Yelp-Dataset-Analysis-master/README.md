Yelp-Dataset-Analysis

https://www.yelp.com had announced the "Yelp Dataset challenge" and invited students to use this data in an innovative way and break ground in research. This project contains a Java application to load and query dataset.

GUI is created using Java Swings and JSON files are loaded into MongoDb database. 
